﻿	Notes on the Supply of Ordnance Survey Digital Data
	---------------------------------------------------

   Directory Structure
   -------------------

   The directory structure is shown below:

			  ROOT 
			   |
		      ------------
		     |            |
		   DATA          DOC 


   The ROOT directory will contain the following ASCII text file:
	  o This file - README.TXT.

   The DATA directory contains the data files.

   The DOC directory will contain the following ASCII text files:
	  o LICENCE.TXT - important licence information.
	  o OS_Open_Names_Header.csv - the header file for CSV.	